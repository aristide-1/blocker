package com.example.blocker

import android.content.Intent
import android.net.VpnService
import android.os.ParcelFileDescriptor
import java.io.FileInputStream
import java.io.FileOutputStream
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.util.concurrent.Executors

/**
 * VPN local : seul le trafic DNS passe par le tunnel (route vers FAKE_DNS).
 * Les requêtes vers un domaine bloqué reçoivent NXDOMAIN, les autres sont
 * relayées vers UPSTREAM_DNS. Rien ne quitte l'appareil, sauf les requêtes DNS normales.
 */
class BlockerVpnService : VpnService() {
    companion object {
        const val ACTION_STOP = "stop"
        private const val FAKE_DNS = "10.0.0.2"
        private const val UPSTREAM_DNS = "1.1.1.1"
    }

    private var tun: ParcelFileDescriptor? = null
    @Volatile private var running = false
    private val pool = Executors.newFixedThreadPool(8)

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            setEnabled(false); shutdown(); stopSelf(); return START_NOT_STICKY
        }
        if (!running) start()
        return START_STICKY
    }

    private fun setEnabled(v: Boolean) =
        getSharedPreferences("state", MODE_PRIVATE).edit().putBoolean("enabled", v).apply()

    private fun start() {
        BlockList.load(this)
        tun = Builder().setSession("Blocker")
            .addAddress("10.0.0.1", 32)
            .addDnsServer(FAKE_DNS)
            .addRoute(FAKE_DNS, 32)
            .establish() ?: return
        running = true
        setEnabled(true)
        Thread { loop(tun!!) }.start()
    }

    private fun shutdown() {
        running = false
        tun?.close(); tun = null
    }

    override fun onRevoke() { shutdown() }
    override fun onDestroy() { shutdown(); super.onDestroy() }

    private fun loop(fd: ParcelFileDescriptor) {
        val input = FileInputStream(fd.fileDescriptor)
        val output = FileOutputStream(fd.fileDescriptor)
        val buf = ByteArray(32767)
        try {
            while (running) {
                val n = input.read(buf)
                if (n <= 0) continue
                val pkt = buf.copyOf(n)
                pool.execute { handle(pkt, output) }
            }
        } catch (_: Exception) { }
    }

    private fun handle(pkt: ByteArray, out: FileOutputStream) {
        if ((pkt[0].toInt() shr 4) != 4) return               // IPv4 uniquement
        val ihl = (pkt[0].toInt() and 0x0F) * 4
        if (pkt[9].toInt() != 17) return                       // UDP
        if (u16(pkt, ihl + 2) != 53) return                    // port 53
        val query = pkt.copyOfRange(ihl + 8, pkt.size)
        val (name, qEnd) = parseQuestion(query) ?: return

        val answer = if (BlockList.isBlocked(name)) nxdomain(query, qEnd)
                     else forward(query) ?: return
        val reply = buildReply(pkt, ihl, answer)
        synchronized(out) { out.write(reply) }
    }

    // --- DNS ---------------------------------------------------------------

    /** Retourne (nom demandé, fin de la section question). */
    private fun parseQuestion(q: ByteArray): Pair<String, Int>? {
        if (q.size < 17) return null
        var i = 12
        val sb = StringBuilder()
        while (i < q.size) {
            val len = q[i].toInt() and 0xFF
            if (len == 0) { i++; break }
            if (len > 63 || i + 1 + len > q.size) return null
            if (sb.isNotEmpty()) sb.append('.')
            sb.append(String(q, i + 1, len, Charsets.US_ASCII))
            i += 1 + len
        }
        return sb.toString() to (i + 4)
    }

    private fun nxdomain(q: ByteArray, qEnd: Int): ByteArray {
        val r = q.copyOf(qEnd)
        r[2] = 0x81.toByte()          // QR=1, RD=1
        r[3] = 0x83.toByte()          // RA=1, RCODE=3 (NXDOMAIN)
        for (k in 6..11) r[k] = 0     // an/ns/ar = 0
        return r
    }

    private fun forward(q: ByteArray): ByteArray? = try {
        DatagramSocket().use { s ->
            protect(s)                // sort du tunnel, évite la boucle
            s.soTimeout = 3000
            s.send(DatagramPacket(q, q.size, InetAddress.getByName(UPSTREAM_DNS), 53))
            val rb = ByteArray(4096)
            val rp = DatagramPacket(rb, rb.size)
            s.receive(rp)
            rb.copyOf(rp.length)
        }
    } catch (_: Exception) { null }

    // --- IP / UDP ----------------------------------------------------------

    private fun buildReply(req: ByteArray, ihl: Int, payload: ByteArray): ByteArray {
        val total = ihl + 8 + payload.size
        val r = ByteArray(total)
        System.arraycopy(req, 0, r, 0, ihl + 8)
        System.arraycopy(req, 16, r, 12, 4)   // src <- dst
        System.arraycopy(req, 12, r, 16, 4)   // dst <- src
        r[ihl] = req[ihl + 2]; r[ihl + 1] = req[ihl + 3]       // ports échangés
        r[ihl + 2] = req[ihl]; r[ihl + 3] = req[ihl + 1]
        r[8] = 64
        put16(r, 2, total)
        put16(r, ihl + 4, 8 + payload.size)
        r[ihl + 6] = 0; r[ihl + 7] = 0                          // checksum UDP optionnel en IPv4
        System.arraycopy(payload, 0, r, ihl + 8, payload.size)
        r[10] = 0; r[11] = 0
        put16(r, 10, checksum(r, ihl))
        return r
    }

    private fun checksum(b: ByteArray, len: Int): Int {
        var sum = 0
        var i = 0
        while (i < len) { sum += u16(b, i); i += 2 }
        while (sum shr 16 != 0) sum = (sum and 0xFFFF) + (sum shr 16)
        return sum.inv() and 0xFFFF
    }

    private fun u16(b: ByteArray, o: Int) = ((b[o].toInt() and 0xFF) shl 8) or (b[o + 1].toInt() and 0xFF)
    private fun put16(b: ByteArray, o: Int, v: Int) { b[o] = (v shr 8).toByte(); b[o + 1] = v.toByte() }
}
