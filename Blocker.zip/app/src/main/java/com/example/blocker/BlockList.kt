package com.example.blocker

import android.content.Context

object BlockList {
    @Volatile private var base: Set<String> = emptySet()     // assets/blocklist.txt
    @Volatile private var custom: Set<String> = emptySet()   // ajouts faits dans l'app

    private fun prefs(ctx: Context) = ctx.getSharedPreferences("blocklist", Context.MODE_PRIVATE)

    fun load(ctx: Context) {
        base = ctx.assets.open("blocklist.txt").bufferedReader().useLines { lines ->
            lines.map { it.trim().lowercase() }
                .filter { it.isNotEmpty() && !it.startsWith("#") }
                .map { it.split(Regex("\\s+")).last() }
                .toHashSet()
        }
        custom = prefs(ctx).getStringSet("custom", emptySet())!!.toSet()
    }

    fun customList(): List<String> = custom.sorted()

    /** "https://www.Site-X.com/page" -> "site-x.com", ou null si invalide. */
    fun normalize(input: String): String? {
        val d = input.trim().lowercase()
            .removePrefix("https://").removePrefix("http://").removePrefix("www.")
            .substringBefore('/').substringBefore('?').trimEnd('.')
        return d.takeIf { Regex("^[a-z0-9-]+(\\.[a-z0-9-]+)+$").matches(it) }
    }

    fun add(ctx: Context, input: String): Boolean {
        val d = normalize(input) ?: return false
        save(ctx, custom + d)
        return true
    }

    fun remove(ctx: Context, domain: String) = save(ctx, custom - domain)

    private fun save(ctx: Context, s: Set<String>) {
        custom = s
        prefs(ctx).edit().putStringSet("custom", s).apply()
    }

    /** Bloque "a.b.example.com" si "example.com" est dans l'une des listes. */
    fun isBlocked(name: String): Boolean {
        var d = name.lowercase().trimEnd('.')
        while (true) {
            if (d in base || d in custom) return true
            val i = d.indexOf('.')
            if (i < 0) return false
            d = d.substring(i + 1)
        }
    }
}
