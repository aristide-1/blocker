package com.example.blocker

import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Intent
import android.net.VpnService
import android.os.Bundle
import android.text.InputType
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    private lateinit var pins: PinStore

    private val vpnPermission =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) {
            if (it.resultCode == RESULT_OK) startVpn()
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        pins = PinStore(this)

        fun btn(label: String, action: () -> Unit) =
            Button(this).apply { text = label; setOnClickListener { action() } }

        setContentView(LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(48, 48, 48, 48)
            addView(TextView(context).apply { text = "Blocage de sites"; textSize = 22f })
            addView(btn("Activer le blocage") { enableBlocking() })
            addView(btn("Désactiver (code requis)") { askPin { stopVpn() } })
            addView(btn("Protéger contre la désinstallation") { requestAdmin() })
            addView(btn("Gérer les sites bloqués (code requis)") { askPin { manageSites() } })
            addView(btn("Mettre à jour les listes (code requis)") { askPin { chooseList() } })
            addView(btn("Changer le code (code requis)") { askPin { createPin(cancelable = true) } })
        })

        if (!pins.hasPin()) createPin(cancelable = false)
    }

    // --- Code PIN ------------------------------------------------------------

    private fun createPin(cancelable: Boolean) {
        val input = pinField()
        AlertDialog.Builder(this)
            .setTitle("Choisissez un code (4 caractères minimum, lettres et chiffres)")
            .setView(input)
            .setCancelable(cancelable)
            .setPositiveButton("Enregistrer") { _, _ ->
                val pin = input.text.toString()
                if (pin.length >= 4) pins.setPin(pin)
                else { toast("Code trop court"); createPin(cancelable) }
            }
            .show()
    }

    private fun askPin(onOk: () -> Unit) {
        val left = pins.lockedMinutesLeft()
        if (left > 0) { toast("Trop d'essais. Réessayez dans $left min."); return }
        val input = pinField()
        AlertDialog.Builder(this)
            .setTitle("Entrez le code")
            .setView(input)
            .setPositiveButton("OK") { _, _ ->
                if (pins.check(input.text.toString())) onOk() else toast("Code incorrect")
            }
            .setNegativeButton("Annuler", null)
            .show()
    }

    private fun pinField() = EditText(this).apply {
        inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
    }

    // --- Liste de sites -------------------------------------------------------

    private fun manageSites() {
        BlockList.loadCustom(this)
        val items = BlockList.customList()
        val b = AlertDialog.Builder(this).setTitle("Sites bloqués (touchez pour retirer)")
        if (items.isEmpty()) b.setMessage("Aucun site ajouté.")
        else b.setItems(items.toTypedArray()) { _, i ->
            BlockList.remove(this, items[i]); toast("Retiré"); manageSites()
        }
        b.setPositiveButton("Ajouter") { _, _ -> addSite() }
            .setNegativeButton("Fermer", null)
            .show()
    }

    private fun addSite() {
        val input = EditText(this).apply {
            hint = "site-x.com"
            inputType = InputType.TYPE_TEXT_VARIATION_URI
        }
        AlertDialog.Builder(this)
            .setTitle("Site à bloquer")
            .setView(input)
            .setPositiveButton("Ajouter") { _, _ ->
                if (BlockList.add(this, input.text.toString())) toast("Ajouté")
                else toast("Adresse invalide")
                manageSites()
            }
            .setNegativeButton("Annuler") { _, _ -> manageSites() }
            .show()
    }

    // --- Listes téléchargées ---------------------------------------------------

    private fun chooseList() {
        val names = arrayOf("Adulte - StevenBlack", "Adulte - HaGeZi (NSFW)")
        val urls = arrayOf(
            "https://raw.githubusercontent.com/StevenBlack/hosts/master/alternates/porn-only/hosts",
            "https://raw.githubusercontent.com/hagezi/dns-blocklists/main/adblock/nsfw.txt"
        )
        AlertDialog.Builder(this)
            .setTitle("Choisir une liste à télécharger")
            .setItems(names) { _, i -> updateList(urls[i]) }
            .setNegativeButton("Annuler", null)
            .show()
    }

    private fun updateList(url: String) {
        toast("Téléchargement en cours...")
        Thread {
            try {
                val n = BlockList.download(this, url)
                runOnUiThread { toast("$n sites ajoutés") }
            } catch (e: Exception) {
                runOnUiThread { toast("Échec : ${e.message}") }
            }
        }.start()
    }

    // --- VPN -----------------------------------------------------------------

    private fun enableBlocking() {
        if (!pins.hasPin()) { createPin(cancelable = false); return }
        val intent = VpnService.prepare(this)
        if (intent == null) startVpn() else vpnPermission.launch(intent)
    }

    private fun startVpn() {
        startService(Intent(this, BlockerVpnService::class.java))
        toast("Blocage activé")
    }

    private fun stopVpn() {
        startService(Intent(this, BlockerVpnService::class.java).setAction(BlockerVpnService.ACTION_STOP))
        toast("Blocage désactivé")
    }

    // --- Anti-désinstallation ------------------------------------------------

    private fun requestAdmin() {
        startActivity(Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN)
            .putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN, ComponentName(this, AdminReceiver::class.java))
            .putExtra(DevicePolicyManager.EXTRA_ADD_EXPLANATION, "Empêche la désinstallation de l'application."))
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
}
