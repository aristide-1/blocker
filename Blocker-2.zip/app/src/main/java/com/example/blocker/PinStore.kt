package com.example.blocker

import android.content.Context
import android.util.Base64
import java.security.MessageDigest
import java.security.SecureRandom
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.PBEKeySpec

class PinStore(ctx: Context) {
    private val p = ctx.getSharedPreferences("pin", Context.MODE_PRIVATE)

    fun hasPin() = p.contains("hash")

    fun setPin(pin: String) {
        val salt = ByteArray(16).also { SecureRandom().nextBytes(it) }
        p.edit()
            .putString("salt", Base64.encodeToString(salt, Base64.NO_WRAP))
            .putString("hash", Base64.encodeToString(hash(pin, salt), Base64.NO_WRAP))
            .putInt("fails", 0).apply()
    }

    fun lockedMinutesLeft(): Long =
        ((p.getLong("lockedUntil", 0) - System.currentTimeMillis()) / 60000 + 1).coerceAtLeast(0)
            .takeIf { p.getLong("lockedUntil", 0) > System.currentTimeMillis() } ?: 0

    fun check(pin: String): Boolean {
        if (lockedMinutesLeft() > 0) return false
        val salt = Base64.decode(p.getString("salt", "")!!, Base64.NO_WRAP)
        val stored = Base64.decode(p.getString("hash", "")!!, Base64.NO_WRAP)
        val ok = MessageDigest.isEqual(hash(pin, salt), stored)
        if (ok) {
            p.edit().putInt("fails", 0).apply()
        } else {
            val fails = p.getInt("fails", 0) + 1
            val e = p.edit().putInt("fails", fails)
            if (fails >= 5) e.putLong("lockedUntil", System.currentTimeMillis() + 5 * 60_000).putInt("fails", 0)
            e.apply()
        }
        return ok
    }

    private fun hash(pin: String, salt: ByteArray): ByteArray =
        SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256")
            .generateSecret(PBEKeySpec(pin.toCharArray(), salt, 100_000, 256)).encoded
}
