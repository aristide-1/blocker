package com.example.blocker

import android.content.Context
import java.io.File
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.util.Arrays

/**
 * Trois sources, fusionnées :
 *  - assets/blocklist.txt        : liste de départ
 *  - filesDir/downloaded.txt     : liste téléchargée (bouton "Mettre à jour")
 *  - sites ajoutés dans l'app    : SharedPreferences
 *
 * Pour économiser la mémoire, les grandes listes ne sont pas gardées en texte :
 * chaque domaine devient une empreinte de 8 octets (FNV-1a 64 bits) dans un tableau trié.
 * 1 million de domaines ~ 8 Mo.
 */
object BlockList {
    private const val DOWNLOAD_FILE = "downloaded.txt"

    @Volatile private var hashes = LongArray(0)
    @Volatile private var custom: Set<String> = emptySet()
    @Volatile var downloadedCount = 0
        private set

    private val DOMAIN = Regex("^[a-z0-9_-]+(\\.[a-z0-9_-]+)+$")
    private val IP = Regex("^[0-9.]+$")

    private fun prefs(ctx: Context) = ctx.getSharedPreferences("blocklist", Context.MODE_PRIVATE)

    private fun hash(s: String): Long {
        var h = -3750763034362895579L          // offset FNV-1a 64 bits
        for (c in s) {
            h = h xor c.code.toLong()
            h *= 1099511628211L
        }
        return h
    }

    private class Longs {
        var a = LongArray(1 shl 16)
        var n = 0
        fun add(v: Long) {
            if (n == a.size) a = a.copyOf(n * 2)
            a[n++] = v
        }
    }

    /** Lit une ligne : domaine simple, format hosts ("0.0.0.0 site.com") ou adblock ("||site.com^"). */
    private fun parseDomain(line: String): String? {
        var t = line.trim()
        if (t.isEmpty() || t[0] == '#' || t[0] == '!' || t[0] == '[') return null
        t = t.substringBefore('#').trim().lowercase()
        if (t.startsWith("||")) t = t.substring(2).substringBefore('^')
        else {
            val i = t.lastIndexOfAny(charArrayOf(' ', '\t'))
            if (i >= 0) t = t.substring(i + 1)
        }
        t = t.removePrefix("*.").removePrefix(".").trimEnd('.')
        if (!DOMAIN.matches(t) || IP.matches(t)) return null
        return t
    }

    /** Charge toutes les sources en mémoire. Peut prendre quelques secondes : à lancer hors du thread principal. */
    fun load(ctx: Context) {
        val acc = Longs()
        ctx.assets.open("blocklist.txt").bufferedReader().useLines { lines ->
            for (l in lines) parseDomain(l)?.let { acc.add(hash(it)) }
        }
        var dl = 0
        val f = File(ctx.filesDir, DOWNLOAD_FILE)
        if (f.exists()) {
            f.bufferedReader().useLines { lines ->
                for (l in lines) parseDomain(l)?.let { acc.add(hash(it)); dl++ }
            }
        }
        val arr = acc.a.copyOf(acc.n)
        arr.sort()
        hashes = arr
        downloadedCount = dl
        loadCustom(ctx)
    }

    fun loadCustom(ctx: Context) {
        custom = prefs(ctx).getStringSet("custom", emptySet())!!.toSet()
    }

    // --- Sites ajoutés à la main ------------------------------------------------

    fun customList(): List<String> = custom.sorted()

    /** "https://www.Site-X.com/page" -> "site-x.com", ou null si invalide. */
    fun normalize(input: String): String? {
        val d = input.trim().lowercase()
            .removePrefix("https://").removePrefix("http://").removePrefix("www.")
            .substringBefore('/').substringBefore('?').trimEnd('.')
        return d.takeIf { DOMAIN.matches(it) }
    }

    fun add(ctx: Context, input: String): Boolean {
        val d = normalize(input) ?: return false
        save(ctx, custom + d)
        return true
    }

    fun remove(ctx: Context, domain: String) = save(ctx, custom - domain)

    private fun save(ctx: Context, s: Set<String>) {
        custom = s
        prefs(ctx).edit().putStringSet("custom", s).apply()
    }

    // --- Téléchargement d'une liste ---------------------------------------------

    /** Télécharge et enregistre une liste. Bloquant : à appeler depuis un thread. Retourne le nombre de domaines. */
    fun download(ctx: Context, url: String): Int {
        val tmp = File(ctx.filesDir, "downloaded.tmp")
        var count = 0
        val conn = URL(url).openConnection() as HttpURLConnection
        conn.connectTimeout = 15_000
        conn.readTimeout = 30_000
        try {
            if (conn.responseCode != 200) throw IOException("erreur HTTP ${conn.responseCode}")
            tmp.bufferedWriter().use { w ->
                conn.inputStream.bufferedReader().useLines { lines ->
                    for (l in lines) parseDomain(l)?.let { w.write(it); w.newLine(); count++ }
                }
            }
        } finally {
            conn.disconnect()
        }
        if (count < 100) { tmp.delete(); throw IOException("liste invalide ($count domaines)") }
        if (!tmp.renameTo(File(ctx.filesDir, DOWNLOAD_FILE))) throw IOException("enregistrement impossible")
        load(ctx)
        return count
    }

    // --- Vérification -----------------------------------------------------------

    /** Bloque "a.b.example.com" si "example.com" est dans l'une des listes. */
    fun isBlocked(name: String): Boolean {
        var d = name.lowercase().trimEnd('.')
        val h = hashes
        val c = custom
        while (true) {
            if (d in c || Arrays.binarySearch(h, hash(d)) >= 0) return true
            val i = d.indexOf('.')
            if (i < 0) return false
            d = d.substring(i + 1)
        }
    }
}
