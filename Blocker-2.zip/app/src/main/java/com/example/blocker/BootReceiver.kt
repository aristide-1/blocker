package com.example.blocker

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.net.VpnService

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        val enabled = ctx.getSharedPreferences("state", Context.MODE_PRIVATE).getBoolean("enabled", false)
        if (enabled && VpnService.prepare(ctx) == null) {
            ctx.startService(Intent(ctx, BlockerVpnService::class.java))
        }
    }
}
