# Blocker (Android)
Projet Gradle complet. Compilation via GitHub Actions (voir les instructions dans la conversation).
Sources : app/src/main/java/com/example/blocker/
